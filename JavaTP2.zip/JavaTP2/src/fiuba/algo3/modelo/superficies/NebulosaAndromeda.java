package fiuba.algo3.modelo.superficies;

import fiuba.algo3.modelo.transformers.AlgoFormer;

public class NebulosaAndromeda extends Aire {

	@Override
	public void actuarSobreAlgoformer(AlgoFormer personaje) {
		// TODO Auto-generated method stub
	}
	
}
