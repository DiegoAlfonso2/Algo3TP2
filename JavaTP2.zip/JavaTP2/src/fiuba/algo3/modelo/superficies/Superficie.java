package fiuba.algo3.modelo.superficies;

import fiuba.algo3.modelo.transformers.AlgoFormer;

public abstract class Superficie {
	
	public abstract void actuarSobreAlgoformer(AlgoFormer personaje);

}
