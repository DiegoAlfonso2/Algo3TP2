package fiuba.algo3.modelo.superficies;

public abstract class Aire extends Superficie {
	
}
