package fiuba.algo3.modelo.superficies;

public abstract class Terreno extends Superficie {
	
}
