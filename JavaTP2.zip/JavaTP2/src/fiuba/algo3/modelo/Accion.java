package fiuba.algo3.modelo;

public interface Accion {

	void ejecutarSobre(Partida partida, Tablero tablero);
}
