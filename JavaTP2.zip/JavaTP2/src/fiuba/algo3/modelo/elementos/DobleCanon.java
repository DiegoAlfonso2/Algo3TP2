package fiuba.algo3.modelo.elementos;

public class DobleCanon extends Bonus {

}
