package fiuba.algo3.modelo.elementos;

public class Flash extends Bonus {

}
