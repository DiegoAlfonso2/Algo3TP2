package fiuba.algo3.modelo.elementos;

public class Burbuja extends Bonus {

}
