package fiuba.algo3.modelo.transformers;

/**
 * Created by Julian Garate on 6/4/16.
 */
abstract class Autobot extends AlgoFormer{

}
