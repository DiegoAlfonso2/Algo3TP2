package fiuba.algo3.modelo;

	public class Jugador {
	
	private String nombre;
		
	public Jugador(String nombre, String tipo) {
		this.nombre = nombre;
	}

	public Jugador(String nombre) {
		this.nombre = nombre;
	}
}
